

const Analytics = () => {
  return (
    <div className="py-80">Analytics</div>
  )
}

export default Analytics