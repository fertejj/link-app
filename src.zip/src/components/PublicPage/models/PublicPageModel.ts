export interface PublicPageModel {
    username: string;
    title: string;
    links: { title: string; url: string }[];
    createdAt: string;
  }
  